import java.util.ArrayList;
import java.util.List;

public class Category implements ProductComponent {

    private String name;
    private List<ProductComponent> children = new ArrayList<>();

    public Category(String name) {
        this.name = name;
    }

    public void add(ProductComponent component) {
        children.add(component);
    }

    public void remove(ProductComponent component) {
        children.remove(component);
    }

    @Override
    public void display() {
        System.out.println("Category: " + name);

        for (ProductComponent component : children) {
            component.display();
        }
    }

    @Override
    public double getPrice() {
        double total = 0;

        for (ProductComponent component : children) {
            total += component.getPrice();
        }

        return total;
    }
}