public class Main {

    public static void main(String[] args) {

        Product laptop = new Product("Laptop", 1200);
        Product phone = new Product("Phone", 800);
        Product headphones = new Product("Headphones", 150);

        Category electronics = new Category("Electronics");
        Category accessories = new Category("Accessories");

        accessories.add(headphones);

        electronics.add(laptop);
        electronics.add(phone);
        electronics.add(accessories);

        electronics.display();

        System.out.println("Total Price: $" + electronics.getPrice());
    }
}