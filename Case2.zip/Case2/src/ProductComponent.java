
interface ProductComponent {
        void display();
    double getPrice();
}
