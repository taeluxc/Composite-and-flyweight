import java.util.ArrayList;
import java.util.List;

public class EmergencyAlertSystem implements Subject {
    
    private List<Observer> observers = new ArrayList<>();
    private String alertMessage;

    @Override
    public void attach(Observer o) {
        observers.add(o);
    }

    @Override
    public void detach(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyObservers() {
        for (Observer o : observers) {
            o.update(alertMessage);
        }
    }

    public void setAlert(String message) {
        this.alertMessage = message;
        System.out.println("\n[SYSTEM] Emergency Alert: " + message);
        notifyObservers();
    }
}
