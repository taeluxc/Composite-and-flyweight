public class PoliceDepartment implements Observer {

    @Override
    public void update(String message) {
        System.out.println("Police Department received: " + message);
    }
}