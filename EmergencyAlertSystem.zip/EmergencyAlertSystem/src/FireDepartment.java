public class FireDepartment implements Observer {

    @Override
    public void update(String message) {
        System.out.println("Fire Department received: " + message);
    }
}