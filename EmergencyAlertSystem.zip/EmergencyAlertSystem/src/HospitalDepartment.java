public class HospitalDepartment implements Observer {

    @Override
    public void update(String message) {
        System.out.println("Hospital Department received: " + message);
    }
}