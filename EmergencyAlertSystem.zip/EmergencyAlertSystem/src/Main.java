public class Main {

     public static void main(String[] args) {

        EmergencyAlertSystem system = new EmergencyAlertSystem();

        Observer police = new PoliceDepartment();
        Observer hospital = new HospitalDepartment();
        Observer fire = new FireDepartment();

        system.attach(police);
        system.attach(hospital);
        system.attach(fire);

        system.setAlert("Earthquake detected in Zone A");

        System.out.println("\n--- Removing Fire Department ---");

        system.detach(fire);

        system.setAlert("Aftershock warning in Zone A");
    }
    
    
    
    
    
}